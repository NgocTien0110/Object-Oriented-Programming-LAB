#include "bai1.h"

Ngay::Ngay()
{
    this->day = 1;
    this->month = 1;
    this->year = 1;
}

Ngay::Ngay(int day)
{
    // chua lam kip :(
}

Ngay::Ngay(int day, int month, int year)
{
    if (year < 1)
        this->year = 1;
    else
        this->year = year;

    if (month > 12 || month < 1)
    {
        if (month > 12)
            this->month = 12;
        else
            this->month = 1;

        if (day < 1)
            this->day = 1;
        else if (day > 31)
            this->day = 31;
        else
            this->day = day;
    }
    else
    {
        if (day < 1)
            this->day = 1;
        else
        {
            switch (month)
            {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
            {
                if (day > 31)
                    this->day = 31;
                else
                    this->day = day;
                break;
            }
            case 4:
            case 6:
            case 9:
            case 11:
            {
                if (day > 30)
                    this->day = 30;
                else
                    this->day = day;
                break;
            }
            case 2:
            {
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                {
                    if (day > 29)
                        this->day = 29;
                    else
                        this->day = day;
                }
                else
                {
                    if (day > 28)
                        this->day = 28;
                    else
                        this->day = day;
                }
            }
            // default:
            //     break;
            }
        }
    }
}

int main()
{
    Ngay n1;
    n1.Xuat();
    Ngay n2(02, 10, 2014);
    n2.Xuat();
    Ngay n3(-10, 16, 2000);
    n3.Xuat();
    // Ngay n4(1000);
    // n4.Xuat();
    return 0;
}