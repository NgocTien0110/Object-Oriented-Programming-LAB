#include <iostream>
using namespace std;

class Ngay
{
private:
    int day;
    int month;
    int year;
public:
    Ngay();
    Ngay(int day);
    Ngay(int day, int month, int year);
    
    void Xuat()
    {
        cout << day << "/" << month << "/" << year << endl;
    }
};