#include <iostream>
using namespace std;

class ThoiGian
{
private:
    int hour;
    int minute;
    int second;
public:
    ThoiGian();
    ThoiGian(int second);
    ThoiGian(int hour, int minute, int second);

    void Xuat()
    {
        cout << hour << ":" << minute << ":" << second << endl;
    }
};