#include "bai2.h"

ThoiGian::ThoiGian()
{
    this->hour = 0;
    this->minute = 0;
    this->second = 0;
}

ThoiGian::ThoiGian(int second)
{
    if(second < 60)
    {
        this->hour = this->minute = 0;
        this->second = second;
    }
    else if(second >= 60 && second < 3600)
    {
        this->hour = 0;
        this->minute = (second-second%60)/60;
        this->second = second%60;
    }
    else
    {
        this->hour = (second-second%3600)/3600;
        this->minute = ((second%3600) - (second%3600)%60)/60;
        this->second = second - this->minute*60 - this->hour*3600;
    }
}

ThoiGian::ThoiGian(int hour, int minute, int second)
{
    if(hour < 0)
        this->hour = 0;        
    else
        this->hour = hour;

    if(minute < 0)
    this->minute = 0;
    else
        this->minute = minute;

    if(second < 0)
        this->second = 0;
    else
        this->second = second;
}

ThoiGian::ThoiGian(int minute, int second)
{
        // chua lam kip :(
}
int main()
{
    ThoiGian tg1;
    tg1.Xuat();
    ThoiGian tg2(1212);
    tg2.Xuat();
    ThoiGian tg3(1,10,1);
    tg3.Xuat();
    ThoiGian tg4;
    tg4.Xuat();

    return 0;
}