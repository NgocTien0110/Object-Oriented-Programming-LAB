#include <iostream>
#include <cmath>
#include <string>
using namespace std;

class HocSinh
{
private:
    string name;
    double m1, m2, m3;
    double dtb;
    int id;
    static int sl;
    static HocSinh HocSinhDatDiemDTBCaoNhat;

public:
    static string HSDiemTBCaoNhat();
 
    HocSinh()
    {
        sl++;
        id = sl;
    }
    HocSinh(string hoten, double mon1, double mon2, double mon3)
    {
        name = hoten;
        m1 = abs(mon1);
        m2 = abs(mon2);
        m3 = abs(mon3);
        dtb = (m1 + m2 + m3) / 3;
        sl++;
        id = sl;
        if (dtb > HocSinhDatDiemDTBCaoNhat.dtb)
        {
            HocSinhDatDiemDTBCaoNhat.id = id;
            HocSinhDatDiemDTBCaoNhat.name = name;
            HocSinhDatDiemDTBCaoNhat.dtb = dtb;
        }
    }
    void DatHoTen(string hoten)
    {
        name = hoten;
    }
    void GanDiem(double mon1, double mon2, double mon3)
    {
        m1 = abs(mon1);
        m2 = abs(mon2);
        m3 = abs(mon3);

        dtb = (m1+m2+m3) / 3;

        if (dtb > HocSinhDatDiemDTBCaoNhat.dtb)
        {
            HocSinhDatDiemDTBCaoNhat.id = id;
            HocSinhDatDiemDTBCaoNhat.name = name;
            HocSinhDatDiemDTBCaoNhat.dtb = dtb;
        }
    }
  

    void Xuat()
    {
        cout << "HS: " << name
            << ", MS: " << id
            << ", DTB: " << dtb;
    }
};

string HocSinh::HSDiemTBCaoNhat()
{
    return "HS: " + HocSinhDatDiemDTBCaoNhat.name + ", MS: " + to_string(HocSinhDatDiemDTBCaoNhat.id) + ", DTB: " + to_string(HocSinhDatDiemDTBCaoNhat.dtb);
}

HocSinh HocSinh::HocSinhDatDiemDTBCaoNhat{};
int HocSinh::sl = 1363001;