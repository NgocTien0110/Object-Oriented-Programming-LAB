#include "bai1.h"

int HocSinh::SoLuongHocSinh = 0;

HocSinh HocSinh::HocSinhDatDiemDTBCaoNhat = {};

HocSinh::HocSinh() {
	this->MSSV = min_MSSV + SoLuongHocSinh;
	this->HoTen = "";
	this->DiemMonThuNhat = this->DiemMonThuHai = this->DiemMonThuBa = this->DiemTrungBinh = 0;
	this->SoLuongHocSinh++;
}

HocSinh::~HocSinh() {
	this->SoLuongHocSinh--;
}

HocSinh::HocSinh(string HoTen, double DiemMonThuNhat, double DiemMonThuHai, double DiemMonThuBa) {
	this->MSSV = min_MSSV + SoLuongHocSinh;
	this->HoTen = HoTen;
	this->DiemMonThuNhat = (DiemMonThuNhat < 0) ? -DiemMonThuNhat : DiemMonThuNhat;
	this->DiemMonThuHai = (DiemMonThuHai < 0) ? -DiemMonThuHai : DiemMonThuHai;
	this->DiemMonThuBa = (DiemMonThuBa < 0) ? -DiemMonThuBa : DiemMonThuBa;
	this->DiemTrungBinh = (this->DiemMonThuNhat + this->DiemMonThuHai + this->DiemMonThuBa) / 3;
	this->SoLuongHocSinh++;

	if (this->DiemTrungBinh > HocSinhDatDiemDTBCaoNhat.DiemTrungBinh) {
		HocSinhDatDiemDTBCaoNhat.MSSV = this->MSSV;
		HocSinhDatDiemDTBCaoNhat.HoTen = this->HoTen;
		HocSinhDatDiemDTBCaoNhat.DiemTrungBinh = this->DiemTrungBinh;
	}
}

void HocSinh::DatHoTen(string HoTen) {
	this->HoTen = HoTen;
}

void HocSinh::GanDiem(double DiemMonThuNhat, double DiemMonThuHai, double DiemMonThuBa) {
	this->DiemMonThuNhat = (DiemMonThuNhat < 0) ? -DiemMonThuNhat : DiemMonThuNhat;
	this->DiemMonThuHai = (DiemMonThuHai < 0) ? -DiemMonThuHai : DiemMonThuHai;
	this->DiemMonThuBa = (DiemMonThuBa < 0) ? -DiemMonThuBa : DiemMonThuBa;
	this->DiemTrungBinh = (this->DiemMonThuNhat + this->DiemMonThuHai + this->DiemMonThuBa) / 3;

	if (this->DiemTrungBinh > HocSinhDatDiemDTBCaoNhat.DiemTrungBinh) {
		HocSinhDatDiemDTBCaoNhat.MSSV = this->MSSV;
		HocSinhDatDiemDTBCaoNhat.HoTen = this->HoTen;
		HocSinhDatDiemDTBCaoNhat.DiemTrungBinh = this->DiemTrungBinh;
	}
}

string HocSinh::HSDiemTBCaoNhat() {
	return "HS: " + HocSinhDatDiemDTBCaoNhat.HoTen + ", MS: " + to_string(HocSinhDatDiemDTBCaoNhat.MSSV) + ", DTB: " + to_string(HocSinhDatDiemDTBCaoNhat.DiemTrungBinh);
}

ostream& operator<<(ostream& os, const HocSinh& hs) {
	return os << "HS: " << hs.HoTen << ", MS: " << hs.MSSV << ", DTB: " << hs.DiemTrungBinh;
}