#include <iostream>
#include <string>

using namespace std;

static int min_MSSV = 1363001;

class HocSinh {
private:
	int MSSV; 
	string HoTen;
	double DiemMonThuNhat;
	double DiemMonThuHai;
	double DiemMonThuBa;
	double DiemTrungBinh;
	static int SoLuongHocSinh;
	static HocSinh HocSinhDatDiemDTBCaoNhat;
public:
	HocSinh();
	~HocSinh();
	HocSinh(string name, double DiemMonThuNhat, double DiemMonThuHai, double DiemMonThuBa);
	void DatHoTen(string HoTen);
	void GanDiem(double DiemMonThuNhat, double DiemMonThuHai, double DiemMonThuBa);
	static string HSDiemTBCaoNhat();
	friend ostream& operator<<(ostream& os, const HocSinh& hs);
};