#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Count
{
private:
	int num;
public:
	Count(void);
	Count(const char *file);
	~Count(void);

	int getNum();
	void printDoc(const char* file);
};
