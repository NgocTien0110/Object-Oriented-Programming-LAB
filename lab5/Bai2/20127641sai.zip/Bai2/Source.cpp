#include "Header.h"

Count::Count(void)
{
	num = 0;
}
Count::Count(const char *file)
{
	ifstream ifs(file);
	if (!ifs.is_open())
		num = 0;
	else
	{
		string t;
		getline(ifs >> ws, t, '\0');

		int i = 0;
		num = 0;
		while (t[i] != '\0')
		{
			if ((t[i] >= 'a' && t[i] <= 'z' || t[i] >= 'A' && t[i] <= 'Z')&&
				(  t[i+1] > 'z' || t[i+1] < 'A' ||( t[i+1] > 'Z' && t[i + 1] < 'a')))
				num++;
			i++;
		}
	}
}
Count::~Count(void)
{
	num = 0;
}
int Count::getNum()
{
	return num;
}
void Count::printDoc(const char* file)
{
	ifstream ifs(file);
	if (!ifs.is_open())
		num = 0;
	else
	{
		string t;
		getline(ifs >> ws, t, '\0');
		cout << t << endl;
	}
}