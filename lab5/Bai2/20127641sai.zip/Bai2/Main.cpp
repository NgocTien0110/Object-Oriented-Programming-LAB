#include "Header.h"

int main()
{
	Count a("vanban.txt");

	cout << "Van ban: " << endl;
	a.printDoc("vanban.txt");

	cout << "\nSo tu trong van ban la: " << a.getNum() << endl;

	return 0;
}