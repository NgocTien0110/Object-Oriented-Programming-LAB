#include "Shape2D.h"

Shape2D::Shape2D() {}
Shape2D::~Shape2D() {}

