#include "Shape3D.h"

Shape3D::Shape3D() {}
Shape3D::~Shape3D() {}

