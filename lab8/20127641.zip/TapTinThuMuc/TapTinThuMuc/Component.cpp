#include "Component.h"
//
//void Component::xuat()
//{
//	cout << "name: " << name << " ";
//	//cout << "size: " << size << endl;
//}