#include "CoMay.h"

int main()
{
	CoMay ABC;
	ABC.nhapChiTiet();
	system("cls");
	ABC.xuatChiTiet();
	ABC.timChiTiet();
	system("pause");
	return 0;
}