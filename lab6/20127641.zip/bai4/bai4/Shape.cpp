#include "Shape.h"

Shape::Shape() {}
Shape::~Shape() {}

